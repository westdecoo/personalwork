import { motion } from "framer-motion";
import { fadeInUp, slideInLeft, slideInRight } from "@/lib/animations";

const About = () => {
  return (
    <section id="about" className="py-20 bg-[hsl(240,3.7%,9.8%)]">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={slideInLeft}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-8">
              About <span className="text-[hsl(187,100%,50%)]">Me</span>
            </h2>

            <div className="space-y-6 text-[hsl(240,5%,64.9%)] text-lg leading-relaxed">
              <p>
                I'm a passionate full-stack developer with{" "}
                <span className="text-[hsl(262,83%,58%)] font-semibold">2+ years</span> of
                experience building scalable web applications. My journey began with curiosity
                about how websites work, and it evolved into a deep love for creating digital
                solutions that matter.
              </p>

              <p>
                Currently specializing in modern JavaScript frameworks, cloud architecture, and
                user experience design. I believe in writing clean, maintainable code and
                creating intuitive interfaces that users love.
              </p>

              <p>
                When I'm not coding, you'll find me exploring new technologies, contributing to
                open source projects, or sharing knowledge with the developer community through{" "}
                <span className="text-[hsl(187,100%,50%)]">tech talks</span> and blog posts.
              </p>
            </div>

            <motion.div
              variants={fadeInUp}
              className="mt-8 flex flex-wrap gap-4"
            >
              <div className="bg-[hsl(240,3.7%,15.9%)] px-4 py-2 rounded-lg">
                <span className="text-[hsl(187,100%,50%)]">💼</span>
                <span className="ml-2 text-[hsl(0,0%,98%)]">2+ Years Experience</span>
              </div>
              <div className="bg-[hsl(240,3.7%,15.9%)] px-4 py-2 rounded-lg">
                <span className="text-[hsl(262,83%,58%)]">🚀</span>
                <span className="ml-2 text-[hsl(0,0%,98%)]">50+ Projects Completed</span>
              </div>
              <div className="bg-[hsl(240,3.7%,15.9%)] px-4 py-2 rounded-lg">
                <span className="text-[hsl(187,100%,50%)]">🌟</span>
                <span className="ml-2 text-[hsl(0,0%,98%)]">Remote Available</span>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={slideInRight}
            className="relative"
          >
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
              alt="Professional developer portrait"
              className="rounded-2xl shadow-2xl w-full max-w-md mx-auto lg:max-w-full"
            />

            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-[hsl(187,100%,50%)]/20 rounded-full blur-xl" />
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-[hsl(262,83%,58%)]/20 rounded-full blur-xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
