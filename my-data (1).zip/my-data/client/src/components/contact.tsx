import { useState } from "react";
import { motion } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Mail, Phone, MapPin, Github, Linkedin, Twitter, Instagram, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { fadeInUp, slideInLeft, slideInRight } from "@/lib/animations";
import { insertContactSchema, type InsertContact } from "@shared/schema";

const Contact = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      subject: "",
      message: "",
      newsletter: false,
    },
  });

  const createContact = useMutation({
    mutationFn: async (data: InsertContact) => {
      const response = await apiRequest("POST", "/api/contacts", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for reaching out. I'll get back to you soon.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to send message",
        description: "Please try again or contact me directly via email.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContact) => {
    createContact.mutate(data);
  };

  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "hello@darknajia.com",
      color: "hsl(187,100%,50%)",
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+1 (617) 276-7244",
      color: "hsl(262,83%,58%)",
    },
    {
      icon: MapPin,
      label: "Location",
      value: "Boston, Ma",
      color: "hsl(187,100%,50%)",
    },
  ];

  const socialLinks = [
    { icon: Linkedin, href: "https://linkedin.com", color: "hsl(187,100%,50%)" },
    { icon: Github, href: "https://github.com", color: "hsl(262,83%,58%)" },
    { icon: Twitter, href: "https://twitter.com", color: "hsl(187,100%,50%)" },
    { icon: Instagram, href: "https://instagram.com", color: "hsl(262,83%,58%)" },
  ];

  return (
    <section id="contact" className="py-20 bg-[hsl(240,10%,3.9%)]">
      <div className="container mx-auto px-6">
        <motion.div
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          variants={fadeInUp}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Let's <span className="text-[hsl(187,100%,50%)]">Connect</span>
          </h2>
          <p className="text-[hsl(240,5%,64.9%)] text-xl max-w-2xl mx-auto">
            Have a project in mind or want to collaborate? I'd love to hear from you.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Information */}
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={slideInLeft}
            className="space-y-8"
          >
            <div className="bg-[hsl(240,3.7%,9.8%)] p-8 rounded-2xl border border-[hsl(240,3.7%,15.9%)]">
              <h3 className="text-2xl font-semibold mb-6 text-[hsl(0,0%,98%)]">Get in Touch</h3>

              <div className="space-y-6">
                {contactInfo.map((info, index) => {
                  const Icon = info.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center space-x-4"
                    >
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: info.color + "10" }}
                      >
                        <Icon size={20} style={{ color: info.color }} />
                      </div>
                      <div>
                        <p className="text-[hsl(240,5%,64.9%)] text-sm">{info.label}</p>
                        <p className="text-[hsl(0,0%,98%)] font-semibold">{info.value}</p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              <div className="mt-8 pt-8 border-t border-[hsl(240,3.7%,15.9%)]">
                <p className="text-[hsl(240,5%,64.9%)] mb-4">Follow me on social media</p>
                <div className="flex space-x-4">
                  {socialLinks.map((social, index) => {
                    const Icon = social.icon;
                    return (
                      <motion.a
                        key={index}
                        href={social.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        whileHover={{ scale: 1.1, y: -2 }}
                        className="w-10 h-10 bg-[hsl(240,3.7%,15.9%)] rounded-lg flex items-center justify-center transition-all duration-300"
                        style={{
                          "--hover-bg": social.color,
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = social.color;
                          e.currentTarget.style.color = "white";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = "hsl(240,3.7%,15.9%)";
                          e.currentTarget.style.color = "hsl(240,5%,64.9%)";
                        }}
                      >
                        <Icon size={18} />
                      </motion.a>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Availability Status */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-[hsl(240,3.7%,9.8%)] p-6 rounded-2xl border border-[hsl(240,3.7%,15.9%)]"
            >
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                <span className="text-[hsl(0,0%,98%)] font-semibold">Available for projects</span>
              </div>
              <p className="text-[hsl(240,5%,64.9%)] text-sm mt-2">
                Currently accepting new freelance projects and collaborations.
              </p>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={slideInRight}
            className="bg-[hsl(240,3.7%,9.8%)] p-8 rounded-2xl border border-[hsl(240,3.7%,15.9%)]"
          >
            <h3 className="text-2xl font-semibold mb-6 text-[hsl(0,0%,98%)]">Send a Message</h3>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-[hsl(240,5%,64.9%)]">First Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="John"
                            {...field}
                            className="bg-[hsl(240,3.7%,15.9%)] border-gray-600 text-[hsl(0,0%,98%)] focus:border-[hsl(187,100%,50%)]"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-[hsl(240,5%,64.9%)]">Last Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Doe"
                            {...field}
                            className="bg-[hsl(240,3.7%,15.9%)] border-gray-600 text-[hsl(0,0%,98%)] focus:border-[hsl(187,100%,50%)]"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[hsl(240,5%,64.9%)]">Email Address</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="john@example.com"
                          {...field}
                          className="bg-[hsl(240,3.7%,15.9%)] border-gray-600 text-[hsl(0,0%,98%)] focus:border-[hsl(187,100%,50%)]"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[hsl(240,5%,64.9%)]">Subject</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-[hsl(240,3.7%,15.9%)] border-gray-600 text-[hsl(0,0%,98%)]">
                            <SelectValue placeholder="Select a subject" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="project">New Project</SelectItem>
                          <SelectItem value="collaboration">Collaboration</SelectItem>
                          <SelectItem value="consultation">Consultation</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[hsl(240,5%,64.9%)]">Message</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Tell me about your project..."
                          rows={5}
                          {...field}
                          className="bg-[hsl(240,3.7%,15.9%)] border-gray-600 text-[hsl(0,0%,98%)] focus:border-[hsl(187,100%,50%)] resize-none"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="newsletter"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="data-[state=checked]:bg-[hsl(187,100%,50%)] data-[state=checked]:border-[hsl(187,100%,50%)]"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-[hsl(240,5%,64.9%)] text-sm cursor-pointer">
                          Subscribe to my newsletter for web development tips and updates
                        </FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  disabled={createContact.isPending}
                  className="w-full bg-[hsl(187,100%,50%)] text-[hsl(240,10%,3.9%)] py-3 px-6 rounded-lg font-semibold hover:bg-[hsl(187,100%,45%)] transition-all duration-300 hover:scale-105"
                >
                  {createContact.isPending ? "Sending..." : "Send Message"}
                  <Send className="ml-2" size={18} />
                </Button>
              </form>
            </Form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
