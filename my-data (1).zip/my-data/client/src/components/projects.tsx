import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { ExternalLink, Github } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fadeInUp, staggerContainer, scaleIn } from "@/lib/animations";
import type { Project } from "@shared/schema";

const Projects = () => {
  const [activeFilter, setActiveFilter] = useState("all");

  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const filters = [
    { id: "all", label: "All Projects" },
    { id: "web", label: "Web Apps" },
    { id: "mobile", label: "Mobile" },
    { id: "api", label: "APIs" },
  ];

  const filteredProjects = projects.filter((project) => {
    if (activeFilter === "all") return true;
    return project.category === activeFilter;
  });

  if (isLoading) {
    return (
      <section className="py-20 bg-[hsl(240,3.7%,9.8%)]">
        <div className="container mx-auto px-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[hsl(187,100%,50%)] mx-auto"></div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="projects" className="py-20 bg-[hsl(240,3.7%,9.8%)]">
      <div className="container mx-auto px-6">
        <motion.div
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="text-center mb-16"
        >
          <motion.h2
            variants={fadeInUp}
            className="text-4xl md:text-5xl font-bold mb-6"
          >
            Featured <span className="text-[hsl(187,100%,50%)]">Projects</span>
          </motion.h2>
          <motion.p
            variants={fadeInUp}
            className="text-[hsl(240,5%,64.9%)] text-xl max-w-2xl mx-auto mb-8"
          >
            Showcase of my recent work and side projects
          </motion.p>

          {/* Project Filter */}
          <motion.div
            variants={fadeInUp}
            className="flex flex-wrap justify-center gap-4 mb-12"
          >
            {filters.map((filter) => (
              <Button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-6 py-2 rounded-lg font-semibold transition-all duration-300 ${
                  activeFilter === filter.id
                    ? "bg-[hsl(187,100%,50%)] text-[hsl(240,10%,3.9%)]"
                    : "bg-[hsl(240,3.7%,15.9%)] text-[hsl(240,5%,64.9%)] hover:bg-[hsl(187,100%,50%)] hover:text-[hsl(240,10%,3.9%)]"
                }`}
              >
                {filter.label}
              </Button>
            ))}
          </motion.div>
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          layout
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence>
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="bg-[hsl(240,10%,3.9%)] rounded-2xl overflow-hidden border border-[hsl(240,3.7%,15.9%)] hover:border-[hsl(187,100%,50%)]/50 transition-all duration-300 group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[hsl(240,10%,3.9%)]/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-[hsl(0,0%,98%)] group-hover:text-[hsl(187,100%,50%)] transition-colors duration-300">
                      {project.title}
                    </h3>
                    <div className="flex space-x-2">
                      {project.liveUrl && (
                        <a
                          href={project.liveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[hsl(240,5%,64.9%)] hover:text-[hsl(187,100%,50%)] transition-colors duration-300"
                        >
                          <ExternalLink size={18} />
                        </a>
                      )}
                      {project.githubUrl && (
                        <a
                          href={project.githubUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[hsl(240,5%,64.9%)] hover:text-[hsl(187,100%,50%)] transition-colors duration-300"
                        >
                          <Github size={18} />
                        </a>
                      )}
                    </div>
                  </div>

                  <p className="text-[hsl(240,5%,64.9%)] mb-4 text-sm leading-relaxed">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className={`px-3 py-1 rounded-full text-xs ${
                          techIndex % 2 === 0
                            ? "bg-[hsl(187,100%,50%)]/10 text-[hsl(187,100%,50%)]"
                            : "bg-[hsl(262,83%,58%)]/10 text-[hsl(262,83%,58%)]"
                        }`}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* View More Projects Button */}
        <motion.div
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          variants={fadeInUp}
          className="text-center mt-12"
        >
          <Button
            variant="outline"
            className="border border-[hsl(187,100%,50%)] text-[hsl(187,100%,50%)] px-8 py-4 rounded-lg font-semibold hover:bg-[hsl(187,100%,50%)] hover:text-[hsl(240,10%,3.9%)] transition-all duration-300"
          >
            View All Projects on GitHub
            <Github className="ml-2" size={18} />
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;
