import { motion } from "framer-motion";
import { Github, Linkedin, Twitter } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    quickLinks: [
      { href: "#home", label: "Home" },
      { href: "#about", label: "About" },
      { href: "#projects", label: "Projects" },
      { href: "#contact", label: "Contact" },
    ],
    services: [
      { href: "#", label: "Web Development" },
      { href: "#", label: "Mobile Apps" },
      { href: "#", label: "API Development" },
      { href: "#", label: "Consulting" },
    ],
  };

  const handleNavClick = (href: string) => {
    if (href.startsWith("#")) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <footer className="bg-[hsl(240,3.7%,9.8%)] border-t border-[hsl(240,3.7%,15.9%)] py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="col-span-2 md:col-span-1"
          >
            <div className="text-2xl font-bold mb-4">
              <span className="text-[hsl(187,100%,50%)]">Code</span>
              <span className="text-[hsl(0,0%,98%)]">Canvas</span>
            </div>
            <p className="text-[hsl(240,5%,64.9%)] text-sm leading-relaxed">
              Full-stack developer passionate about creating innovative digital
              solutions with modern technologies.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <h4 className="text-[hsl(0,0%,98%)] font-semibold mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2 text-[hsl(240,5%,64.9%)] text-sm">
              {footerLinks.quickLinks.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="hover:text-[hsl(187,100%,50%)] transition-colors duration-300"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <h4 className="text-[hsl(0,0%,98%)] font-semibold mb-4">
              Services
            </h4>
            <ul className="space-y-2 text-[hsl(240,5%,64.9%)] text-sm">
              {footerLinks.services.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="hover:text-[hsl(187,100%,50%)] transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <h4 className="text-[hsl(0,0%,98%)] font-semibold mb-4">
              Get in Touch
            </h4>
            <div className="space-y-2 text-[hsl(240,5%,64.9%)] text-sm">
              <p>hello@codecanvas.dev</p>
              <p>+1 (617) 276-7244</p>
              <p>Boston, MA</p>
            </div>

            <div className="flex space-x-3 mt-4">
              {[
                { icon: Github, href: "https://github.com" },
                { icon: Linkedin, href: "https://linkedin.com" },
                { icon: Twitter, href: "https://twitter.com" },
              ].map((social, index) => {
                const Icon = social.icon;
                return (
                  <motion.a
                    key={index}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1, y: -2 }}
                    className="text-[hsl(240,5%,64.9%)] hover:text-[hsl(187,100%,50%)] transition-colors duration-300"
                  >
                    <Icon size={18} />
                  </motion.a>
                );
              })}
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="border-t border-[hsl(240,3.7%,15.9%)] mt-8 pt-8 text-center"
        >
          <p className="text-[hsl(240,5%,64.9%)] text-sm">
            © {currentYear} Code Canvas. All rights reserved. Built with
            passion and modern web technologies.
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
