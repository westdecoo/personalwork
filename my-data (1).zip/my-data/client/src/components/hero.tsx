import { motion } from "framer-motion";
import { Github, Linkedin, Twitter, Mail, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  fadeInUp,
  staggerContainer,
  floatingAnimation,
  glowAnimation,
} from "@/lib/animations";

const Hero = () => {
  const handleScrollToProjects = () => {
    const element = document.querySelector("#projects");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDownloadCV = () => {
    // TODO: Implement CV download
    console.log("Download CV");
  };

  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20"
    >
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[hsl(240,10%,3.9%)] via-[hsl(240,3.7%,9.8%)] to-[hsl(240,3.7%,15.9%)]" />

      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='7' cy='7' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          animate="animate"
          className="max-w-4xl mx-auto"
        >
          <motion.div
            variants={fadeInUp}
            className="inline-block mb-6 px-4 py-2 bg-[hsl(240,3.7%,9.8%)]/50 rounded-full border border-[hsl(187,100%,50%)]/30"
          >
            <span className="text-[hsl(187,100%,50%)] font-mono text-sm">
              $ westdecool
            </span>
          </motion.div>

          <motion.h1
            variants={fadeInUp}
            className="text-5xl md:text-7xl font-bold mb-6 leading-tight"
          >
            <span className="text-[hsl(0,0%,98%)]">Full Stack</span>
            <br />
            <motion.span
              {...glowAnimation}
              className="text-[hsl(187,100%,50%)] inline-block"
            >
              Developer
            </motion.span>
          </motion.h1>

          <motion.p
            variants={fadeInUp}
            className="text-xl md:text-2xl text-[hsl(240,5%,64.9%)] mb-8 max-w-3xl mx-auto leading-relaxed"
          >
            Crafting digital experiences with modern technologies and clean
            code. Specializing in{" "}
            <span className="text-[hsl(262,83%,58%)]">React</span>,{" "}
            <span className="text-[hsl(187,100%,50%)]">Node.js</span>, and cloud
            solutions.
          </motion.p>

          <motion.div
            variants={fadeInUp}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
          >
            <Button
              onClick={handleScrollToProjects}
              className="bg-[hsl(187,100%,50%)] text-[hsl(240,10%,3.9%)] px-8 py-4 rounded-lg font-semibold hover:bg-[hsl(187,100%,45%)] transition-all duration-300 hover:scale-105"
            >
              View My Work
            </Button>
            <Button
              onClick={handleDownloadCV}
              variant="outline"
              className="border border-[hsl(262,83%,58%)] text-[hsl(262,83%,58%)] px-8 py-4 rounded-lg font-semibold hover:bg-[hsl(262,83%,58%)] hover:text-white transition-all duration-300"
            >
              Download CV
            </Button>
          </motion.div>

          {/* Social Links */}
          <motion.div
            variants={fadeInUp}
            className="flex justify-center space-x-6 mb-16"
          >
            {[
              { icon: Github, href: "https://github.com" },
              { icon: Linkedin, href: "https://linkedin.com" },
              { icon: Twitter, href: "https://twitter.com" },
              { icon: Mail, href: "mailto:hello@darknajia.com" },
            ].map((social, index) => (
              <motion.a
                key={index}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.2, y: -5 }}
                className="text-[hsl(240,5%,64.9%)] hover:text-[hsl(187,100%,50%)] transition-colors duration-300 text-2xl"
              >
                <social.icon size={24} />
              </motion.a>
            ))}
          </motion.div>
        </motion.div>

        {/* Floating Elements */}
        <motion.div
          {...floatingAnimation}
          className="absolute top-20 left-10 w-20 h-20 bg-[hsl(187,100%,50%)]/10 rounded-full"
        />
        <motion.div
          {...floatingAnimation}
          style={{ animationDelay: "-2s" }}
          className="absolute bottom-20 right-10 w-32 h-32 bg-[hsl(262,83%,58%)]/10 rounded-full"
        />

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-6 h-10 border-2 border-[hsl(240,5%,64.9%)] rounded-full flex justify-center"
          >
            <motion.div
              animate={{ y: [0, 16, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1 h-3 bg-[hsl(187,100%,50%)] rounded-full mt-2"
            />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
