import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Code, Server, Cloud, Gavel } from "lucide-react";
import { fadeInUp, staggerContainer } from "@/lib/animations";
import type { Skill } from "@shared/schema";

const Skills = () => {
  const { data: skills = [], isLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
  });

  const skillCategories = [
    {
      title: "Frontend",
      icon: Code,
      color: "hsl(187,100%,50%)",
      category: "frontend",
    },
    {
      title: "Backend",
      icon: Server,
      color: "hsl(262,83%,58%)",
      category: "backend",
    },
    {
      title: "DevOps",
      icon: Cloud,
      color: "hsl(187,100%,50%)",
      category: "devops",
    },
    {
      title: "Tools",
      icon: Gavel,
      color: "hsl(262,83%,58%)",
      category: "tools",
    },
  ];

  const getSkillsByCategory = (category: string) => {
    return skills.filter((skill) => skill.category === category);
  };

  const renderProgressBar = (level: string) => {
    const percentage = parseInt(level);
    return (
      <div className="w-16 h-2 bg-[hsl(240,3.7%,15.9%)] rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${percentage}%` }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.5 }}
          className="h-full bg-gradient-to-r from-[hsl(187,100%,50%)] to-[hsl(262,83%,58%)] rounded-full"
        />
      </div>
    );
  };

  if (isLoading) {
    return (
      <section className="py-20 bg-[hsl(240,10%,3.9%)]">
        <div className="container mx-auto px-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[hsl(187,100%,50%)] mx-auto"></div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="skills" className="py-20 bg-[hsl(240,10%,3.9%)]">
      <div className="container mx-auto px-6">
        <motion.div
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="text-center mb-16"
        >
          <motion.h2
            variants={fadeInUp}
            className="text-4xl md:text-5xl font-bold mb-6"
          >
            Technical <span className="text-[hsl(187,100%,50%)]">Skills</span>
          </motion.h2>
          <motion.p
            variants={fadeInUp}
            className="text-[hsl(240,5%,64.9%)] text-xl max-w-2xl mx-auto"
          >
            A comprehensive toolkit for building modern, scalable applications
          </motion.p>
        </motion.div>

        <motion.div
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {skillCategories.map((category, index) => {
            const categorySkills = getSkillsByCategory(category.category);
            const Icon = category.icon;

            return (
              <motion.div
                key={category.category}
                variants={fadeInUp}
                className="bg-[hsl(240,3.7%,9.8%)] p-8 rounded-2xl border border-[hsl(240,3.7%,15.9%)] hover:border-opacity-50 transition-all duration-300 group"
                style={{
                  "--hover-color": category.color,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = category.color + "50";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = "hsl(240,3.7%,15.9%)";
                }}
              >
                <div
                  className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300"
                  style={{ color: category.color }}
                >
                  <Icon size={48} />
                </div>
                <h3 className="text-xl font-semibold mb-4 text-[hsl(0,0%,98%)]">
                  {category.title}
                </h3>
                <div className="space-y-3">
                  {categorySkills.map((skill) => (
                    <div
                      key={skill.id}
                      className="flex items-center justify-between"
                    >
                      <span className="text-[hsl(240,5%,64.9%)] text-sm">
                        {skill.name}
                      </span>
                      {renderProgressBar(skill.level)}
                    </div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Technology Stack Showcase */}
        <motion.div
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          variants={fadeInUp}
          className="mt-16 bg-[hsl(240,3.7%,9.8%)] rounded-2xl p-8 border border-[hsl(240,3.7%,15.9%)]"
        >
          <h3 className="text-2xl font-semibold mb-8 text-center text-[hsl(0,0%,98%)]">
            Technology Stack
          </h3>
          <div className="flex flex-wrap justify-center gap-6">
            {[
              { name: "React", color: "hsl(187,100%,50%)" },
              { name: "Node.js", color: "hsl(262,83%,58%)" },
              { name: "Python", color: "hsl(187,100%,50%)" },
              { name: "AWS", color: "hsl(262,83%,58%)" },
              { name: "Docker", color: "hsl(187,100%,50%)" },
              { name: "Git", color: "hsl(262,83%,58%)" },
            ].map((tech, index) => (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="bg-[hsl(240,3.7%,15.9%)] px-4 py-2 rounded-lg hover:bg-opacity-80 transition-all duration-300 cursor-pointer"
                style={{
                  boxShadow: `0 0 0 1px ${tech.color}20`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = tech.color + "10";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "hsl(240,3.7%,15.9%)";
                }}
              >
                <span className="text-[hsl(0,0%,98%)]">{tech.name}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;
