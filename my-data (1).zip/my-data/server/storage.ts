import { contacts, projects, skills, users, type Contact, type Project, type Skill, type User, type InsertContact, type InsertProject, type InsertSkill, type InsertUser } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  
  // Project methods
  getProjects(): Promise<Project[]>;
  getFeaturedProjects(): Promise<Project[]>;
  getProjectsByCategory(category: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  
  // Skill methods
  getSkills(): Promise<Skill[]>;
  getSkillsByCategory(category: string): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contacts: Map<number, Contact>;
  private projects: Map<number, Project>;
  private skills: Map<number, Skill>;
  private currentUserId: number;
  private currentContactId: number;
  private currentProjectId: number;
  private currentSkillId: number;

  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.projects = new Map();
    this.skills = new Map();
    this.currentUserId = 1;
    this.currentContactId = 1;
    this.currentProjectId = 1;
    this.currentSkillId = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Initialize sample projects
    const sampleProjects: Project[] = [
      {
        id: this.currentProjectId++,
        title: "E-commerce Platform",
        description: "Full-stack e-commerce solution with React, Node.js, and Stripe integration. Features include user authentication, product management, and real-time inventory tracking.",
        imageUrl: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        category: "web",
        technologies: ["React", "Node.js", "MongoDB", "Stripe"],
        githubUrl: "https://github.com/darknajia/ecommerce-platform",
        liveUrl: "https://ecommerce-demo.darknajia.com",
        featured: true,
        createdAt: new Date(),
      },
      {
        id: this.currentProjectId++,
        title: "TaskFlow Pro",
        description: "Modern task management application with real-time collaboration, drag-and-drop functionality, and team workspace features. Built with Vue.js and Firebase.",
        imageUrl: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        category: "web",
        technologies: ["Vue.js", "Firebase", "TypeScript", "PWA"],
        githubUrl: "https://github.com/darknajia/taskflow-pro",
        liveUrl: "https://taskflow.darknajia.com",
        featured: true,
        createdAt: new Date(),
      },
      {
        id: this.currentProjectId++,
        title: "Microservices Gateway",
        description: "Scalable API gateway handling authentication, rate limiting, and service routing. Deployed on AWS with Docker containers and automated CI/CD pipeline.",
        imageUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        category: "api",
        technologies: ["Node.js", "Express", "AWS", "Docker"],
        githubUrl: "https://github.com/darknajia/api-gateway",
        liveUrl: null,
        featured: false,
        createdAt: new Date(),
      },
      {
        id: this.currentProjectId++,
        title: "Fitness Tracker",
        description: "Cross-platform mobile app for fitness tracking with workout plans, progress analytics, and social features. Built with React Native and integrated with health APIs.",
        imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        category: "mobile",
        technologies: ["React Native", "Expo", "Redux", "Health API"],
        githubUrl: "https://github.com/darknajia/fitness-tracker",
        liveUrl: null,
        featured: false,
        createdAt: new Date(),
      },
      {
        id: this.currentProjectId++,
        title: "Analytics Dashboard",
        description: "Real-time analytics dashboard with interactive charts, custom reporting, and data visualization. Features advanced filtering and export capabilities.",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        category: "web",
        technologies: ["D3.js", "React", "Python", "PostgreSQL"],
        githubUrl: "https://github.com/darknajia/analytics-dashboard",
        liveUrl: "https://analytics.darknajia.com",
        featured: true,
        createdAt: new Date(),
      },
      {
        id: this.currentProjectId++,
        title: "AI Assistant",
        description: "Intelligent chatbot with natural language processing, context awareness, and integration with multiple AI models. Features voice recognition and multilingual support.",
        imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
        category: "api",
        technologies: ["OpenAI", "Python", "FastAPI", "WebSocket"],
        githubUrl: "https://github.com/darknajia/ai-assistant",
        liveUrl: "https://ai.darknajia.com",
        featured: false,
        createdAt: new Date(),
      },
    ];

    // Initialize sample skills
    const sampleSkills: Skill[] = [
      // Frontend Skills
      { id: this.currentSkillId++, name: "React.js", category: "frontend", level: "90", icon: "react" },
      { id: this.currentSkillId++, name: "Vue.js", category: "frontend", level: "85", icon: "vue" },
      { id: this.currentSkillId++, name: "TypeScript", category: "frontend", level: "88", icon: "typescript" },
      { id: this.currentSkillId++, name: "Tailwind CSS", category: "frontend", level: "95", icon: "tailwind" },
      
      // Backend Skills
      { id: this.currentSkillId++, name: "Node.js", category: "backend", level: "90", icon: "nodejs" },
      { id: this.currentSkillId++, name: "Python", category: "backend", level: "85", icon: "python" },
      { id: this.currentSkillId++, name: "PostgreSQL", category: "backend", level: "80", icon: "postgresql" },
      { id: this.currentSkillId++, name: "GraphQL", category: "backend", level: "85", icon: "graphql" },
      
      // DevOps Skills
      { id: this.currentSkillId++, name: "AWS", category: "devops", level: "85", icon: "aws" },
      { id: this.currentSkillId++, name: "Docker", category: "devops", level: "90", icon: "docker" },
      { id: this.currentSkillId++, name: "Kubernetes", category: "devops", level: "75", icon: "kubernetes" },
      { id: this.currentSkillId++, name: "CI/CD", category: "devops", level: "85", icon: "github-actions" },
      
      // Tools
      { id: this.currentSkillId++, name: "Git", category: "tools", level: "95", icon: "git" },
      { id: this.currentSkillId++, name: "VS Code", category: "tools", level: "95", icon: "vscode" },
      { id: this.currentSkillId++, name: "Figma", category: "tools", level: "85", icon: "figma" },
      { id: this.currentSkillId++, name: "Postman", category: "tools", level: "90", icon: "postman" },
    ];

    sampleProjects.forEach(project => this.projects.set(project.id, project));
    sampleSkills.forEach(skill => this.skills.set(skill.id, skill));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Contact methods
  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.currentContactId++;
    const contact: Contact = {
      ...insertContact,
      id,
      createdAt: new Date(),
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort(
      (a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  // Project methods
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort(
      (a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getFeaturedProjects(): Promise<Project[]> {
    return Array.from(this.projects.values())
      .filter(project => project.featured)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getProjectsByCategory(category: string): Promise<Project[]> {
    return Array.from(this.projects.values())
      .filter(project => project.category === category)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = {
      ...insertProject,
      id,
      createdAt: new Date(),
    };
    this.projects.set(id, project);
    return project;
  }

  // Skill methods
  async getSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }

  async getSkillsByCategory(category: string): Promise<Skill[]> {
    return Array.from(this.skills.values()).filter(
      skill => skill.category === category
    );
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const id = this.currentSkillId++;
    const skill: Skill = { ...insertSkill, id };
    this.skills.set(id, skill);
    return skill;
  }
}

export const storage = new MemStorage();
